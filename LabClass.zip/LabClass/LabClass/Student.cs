﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabClass
{
    class Student
    {
        private int id;
        private string name;
        private double cgpa;

        public Student(string name, int id, double cgpa)
        {
            this.name = name;
            this.id = id;
            this.cgpa = cgpa;

        }
        public int Id
        {
            get { return this.id; }
            set { this.id = value; }
        }
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public double Cgpa
        {
            set { this.cgpa = value; }
            get { return this.cgpa; }
        }

        public void ShowInfo()
        {
            Console.WriteLine("\tName = {0} \n\tId = {1} \n\tCGPA = {2}", this.name, this.id, this.cgpa);
        }

    }
}
