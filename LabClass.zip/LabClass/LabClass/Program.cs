﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabClass
{
    class Program
    {
        static void Main(string[] args)
        {
            University myUniversity = new University("AIUB",5);
            myUniversity.AddStudents(new Student("Habib",1,3.81));
            myUniversity.AddStudents(new Student("Sajib", 2, 4.00));
            myUniversity.AddStudents(new Student("Rasel", 3, 3.50));
            myUniversity.AddStudents(new Student("Dipto", 4, 3.75));
            myUniversity.AddStudents(new Student("Sajid", 5, 3.77));

            Console.Write("Enter Student Id = ");
            int id = Convert.ToInt32(Console.ReadLine());
            myUniversity.GetStudentId(id);
            myUniversity.PrintAllStudents();
            myUniversity.GetStudentbyCgpaOrder();
            myUniversity.PrintAllStudents();

        }
    }
}
