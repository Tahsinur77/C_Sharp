﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabClass
{
    class University
    {
        private Student[] students;
        private string name;

        public University(string name,int size)
        {
            this.name = name;
            this.students = new Student[size];
        }

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public Student[] Students
        {
            get { return this.students; }
        }

        public void AddStudents(Student student)
        {
            for(int i = 0; i < students.Length; i++)
            {
                if(students[i] == null)
                {
                    students[i] = student;
                    break;
                }
            }
        }

        public void GetStudentId(int id)
        {
            bool flag = false;
            for (int i = 0; i < students.Length; i++)
            {
                if(students[i] == null) continue;
                else if(students[i].Id == id)
                {
                    Console.WriteLine("Found the Student .......\nStuden information =>");
                    students[i].ShowInfo();
                    flag = false;
                    break;
                }
                else
                {
                    flag = true;
                }
            }
            if (flag) Console.WriteLine("Student not found......");
        }

        public void GetStudentbyCgpaOrder()
        {
            Console.WriteLine("After Sorting =>");
            Array.Sort(students,delegate (Student s1, Student s2)
            {
                return s1.Cgpa.CompareTo(s2.Cgpa);
            });
            Array.Reverse(Students);
        }

        public void PrintAllStudents()
        {
            Console.WriteLine("Studen information =>");
            for (int i = 0; i < students.Length; i++)
            {
                if (students[i] == null)
                {
                    continue;
                }
                students[i].ShowInfo();
            }
        }


    }
}
